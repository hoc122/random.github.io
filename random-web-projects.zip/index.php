<?php
if ($_SERVER['REQUEST_METHOD']==='POST' && strstr($_SERVER['HTTP_ACCEPT'],'application/json')) {
  $data = json_decode(file_get_contents('php://input'), true);
  $min = isset($data['min']) ? (int)$data['min'] : 1;
  $max = isset($data['max']) ? (int)$data['max'] : 100;
  $type = $data['type'] ?? 'int';
  $count = min(100, max(1, (int)($data['count'] ?? 1)));
  $precision = max(0, min(10, (int)($data['precision'] ?? 2)));
  $unique = !empty($data['unique']);
  if ($min>$max){ http_response_code(400); echo json_encode(['error'=>'min>max']); exit; }
  $results = []; $used = [];
  for ($i=0;$i<$count;$i++){
    if ($type=='float'){
      $v = $min + lcg_value()*($max-$min);
      $v = round($v,$precision);
    } else {
      if ($unique){
        if (($max-$min+1) < $count){ http_response_code(400); echo json_encode(['error'=>'not enough unique']); exit; }
        do { $v = rand($min,$max); } while (in_array($v,$used));
        $used[]=$v;
      } else $v = rand($min,$max);
    }
    $results[] = $v;
  }
  header('Content-Type: application/json');
  echo json_encode(['results'=>$results]);
  exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Random PHP</title></head><body>
<h3>Random số — PHP single-file</h3>
<form id="f"><input id="min" value="1"><input id="max" value="100"><select id="type"><option>int</option><option>float</option></select>
<input id="count" value="1" style="width:50px"><button id="go">Random</button></form>
<pre id="out">—</pre>
<script>
document.getElementById('f').addEventListener('submit', async e=>{ e.preventDefault();
 const body = {min:document.getElementById('min').value,max:document.getElementById('max').value,type:document.getElementById('type').value,count:document.getElementById('count').value};
 const res = await fetch(location.href, {method:'POST', headers:{'Accept':'application/json','Content-Type':'application/json'}, body:JSON.stringify(body)});
 const j = await res.json(); document.getElementById('out').textContent = j.results ? j.results.join(', ') : JSON.stringify(j);
});
</script>
</body></html>
