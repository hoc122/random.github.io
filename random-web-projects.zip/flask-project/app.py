from flask import Flask, request, jsonify, send_from_directory
import random, math, os
app = Flask(__name__, static_folder='static')
@app.route('/')
def index():
    return send_from_directory('static','index.html')
@app.route('/api/random', methods=['POST'])
def api_random():
    data = request.get_json() or {}
    mn = float(data.get('min',1)); mx = float(data.get('max',100))
    typ = data.get('type','int'); count = int(data.get('count',1)); prec = int(data.get('precision',2)); unique = bool(data.get('unique',False))
    if mn>mx: return jsonify({'error':'min>max'}),400
    results = []; used = set()
    for i in range(min(100,count)):
        if typ=='float':
            v = round(random.random()*(mx-mn)+mn, prec)
        else:
            if unique:
                if mx-mn+1 < count: return jsonify({'error':'not enough unique ints'}),400
                while True:
                    v = random.randint(math.ceil(mn), math.floor(mx))
                    if v not in used:
                        used.add(v); break
            else:
                v = random.randint(math.ceil(mn), math.floor(mx))
        results.append(v)
    return jsonify({'results':results})
if __name__=='__main__':
    port = int(os.environ.get('PORT',5000))
    app.run(host='0.0.0.0', port=port)
