const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));
app.post('/api/random',(req,res)=>{
  const {min=1,max=100,type='int',count=1,precision=2,unique=false} = req.body || {};
  const mn = Number(min), mx = Number(max);
  if(!isFinite(mn) || !isFinite(mx) || mn>mx) return res.status(400).json({error:'Invalid min/max'});
  const results = []; const used = new Set();
  function randInt(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
  function randFloat(min,max,p){ return Number((Math.random()*(max-min)+min).toFixed(p)); }
  for(let i=0;i<Math.min(100, Number(count)); i++){
    let v;
    if(type==='float') v = randFloat(mn,mx,precision);
    else {
      if(unique){
        if(mx-mn+1 < count) return res.status(400).json({error:'Not enough unique ints'});
        do { v = randInt(mn,mx); } while(used.has(v));
        used.add(v);
      } else v = randInt(mn,mx);
    }
    results.push(v);
  }
  res.json({results});
});
app.listen(PORT, ()=> console.log('Server listening on',PORT));
